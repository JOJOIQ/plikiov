Plik README.TXT

Paczka tekstur jojooverlay 

Customowe modele:

\nazwane totemy na pelerynki/ (działa w prawej rece )
* minecraft - pelerynka z logiem minecraft 
* jojo - pelerynka z glowa JOJO_QI i linkiem do stronki 
* czerwona - pelerynka z czerwonym gradientem 
* niebieska - pelerynka z niebieskim gradientem


link do strony głównej HTTPS://WWW.JOJOOV.PL