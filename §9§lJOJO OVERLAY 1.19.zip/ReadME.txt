Plik README.TXT

Paczka tekstur jojoov 

link do strony głównej HTTPS://WWW.JOJOOV.PL